module mis.c112118216 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens mis.c112118216 to javafx.fxml;
    exports mis.c112118216;
}
