module mis.c112118216order {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens mis.c112118216order to javafx.fxml;
    exports mis.c112118216order;
}
