module mis.c112118216bmi {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens mis.c112118216bmi to javafx.fxml;
    exports mis.c112118216bmi;
}
